from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth import get_user_model
from django.contrib import auth, messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse
from Accounts .models import *
from django.conf import settings
from  .utility import generateKey, verify_otp
import random
from django.core.mail import send_mail
from .emails import email_message
from django.views.decorators.csrf import csrf_protect


@csrf_protect
def login_view(request):
    if request.user.is_authenticated:
        next_url = request.GET.get('next', 'home') 
        return redirect(next_url)
    
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        next_url = request.POST.get('next', 'home') 
        
        user = authenticate(email=email, password=password)
        if user is not None:
            login(request, user)
            return redirect(next_url)
        else:
            messages.error(request, 'Invalid Username or Password')
            return redirect(f"{request.path}?next={next_url}")
    
    return render(request, 'accounts/login.html', {'next': request.GET.get('next', 'home')})



def signup_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    if request.method == 'POST':
        if request.POST.get('password') == request.POST.get('confirm_password'):
            if get_user_model().objects.filter(email=request.POST.get('email')).exists():
                    messages.info(request, 'Email already exists')
                    return redirect('accounts:signup')
            elif get_user_model().objects.filter(email=request.POST.get('email')) == '':
                    messages.info(request,'Invalid input')
                    return redirect('accounts:signup')
                
            else:
                    request.session['first_name'] = request.POST.get('first_name')
                    request.session['last_name'] = request.POST.get('last_name')
                    request.session['email'] = request.POST.get('email')
                    request.session['phone_number'] = request.POST.get('phone_number')
                    request.session['date_of_birth'] = request.POST.get('date_of_birth')
                    request.session['password']= request.POST.get('password')
                    request.session['confirm_password'] = request.POST.get('confirm_password')
                    request.session['next_of_kin_name'] = request.POST.get('next_of_kin_name')
                    request.session['next_of_kin_phone_number'] = request.POST.get('next_of_kin_phone_number')
                
                                          
                        
                    try:
                            otp = OTPLog.objects.get(email=request.POST.get('email')).otp
                    except:
                            otp = random.randint(100000, 999999)
                            OTPLog.objects.create(email=request.POST.get('email'), otp=otp).save()

                    message = 'Your OTP is: ' + str(otp)
                    email_message(request.POST.get('email'), 'Registration OTP', message)
                    return redirect('/accounts/signup_otp/')
        else:
                messages.error(request, 'Your passwords do not match')               
    
        
    return render(request, 'accounts/signup.html')

def signup_otp_view(request):
    context = {
        'title': 'OTP Verification',
        'email': request.session['email']
    }

    if request.POST == "GET":
        print("Resend OTP")

    print(OTPLog.objects.get(email=request.session['email']).otp)
    if request.method == "POST":
        otp = OTPLog.objects.get(email=request.session['email'])
        if int(request.POST.get('otp')) == int(otp.otp):
            user =  get_user_model().objects.create_user(
                first_name=request.session['first_name'],
                last_name=request.session['last_name'],
                phone_number=request.session['phone_number'],
                email=request.session['email'],
                date_of_birth=request.session['date_of_birth'],
                next_of_kin_name=request.session['next_of_kin_name'],
                next_of_kin_phone_number=request.session['next_of_kin_phone_number'],
                password=request.session['password'],
            )
            user.save()

            if user is not None:
                login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Wrong OTP')
    return render(request, 'accounts/signup_otp.html', ) 


def logout_view(request):
    logout(request)
    return redirect('home')

def reset_email_sent(request):
    return render(request, 'accounts/reset_email_sent.html',) 
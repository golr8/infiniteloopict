from django.shortcuts import render, get_object_or_404, redirect
from django.http import JsonResponse
import json
import datetime
from .models import * 
from .utils import cookieCart, cartData 
from django.db.models import Q
from django.contrib.auth.decorators import login_required
import random
import string
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings
import requests

def home(request):
	user = request.user
	return render(request, 'home.html', {'user':user})

@login_required(login_url='accounts:login')
def myaccount(request):
    user = request.user
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone_number = request.POST.get('phone_number')
        password = request.POST.get('password')
        next_of_kin_name = request.POST.get('next_of_kin_name')
        next_of_kin_phone_number = request.POST.get('next_of_kin_phone_number')
        date_of_birth = request.POST.get('date_of_birth')

        if email:
            user.email = email

        if first_name:
            user.first_name = first_name

        if last_name:
            user.last_name = last_name

        if phone_number:
            user.phone_number = phone_number

        if next_of_kin_name:
            user.next_of_kin_name = next_of_kin_name

        if next_of_kin_phone_number:
            user.next_of_kin_phone_number = next_of_kin_phone_number

        if date_of_birth:
            user.date_of_birth = date_of_birth
        
        if password:
            user.set_password(password)
            update_session_auth_hash(request, user)  
        user.save()
        return redirect('myaccount') 

    return render(request, 'myaccount.html',)


@login_required(login_url='accounts:login')
def store(request):
	user = request.user
	data = cartData(request)
	cartItems = data['cartItems']
	order = data['order']
	items = data['items']
	products = Product.objects.all()
	categories = Category.objects.all()
	context = {'products':products, 'cartItems':cartItems, 'user':user, 'categories': categories}
	return render(request, 'ecommerce/store.html', context)

@login_required(login_url='accounts:login')
def search(request):
    categories = Category.objects.all()
    object_list = Product.objects.all()
    if 'keywords' in request.GET:
        keywords = request.GET['keywords']
        if keywords:
             object_list = object_list.filter(Q(name__icontains = keywords)| Q(description__icontains = keywords))

    return render(request, 'ecommerce/search.html', {'object_list': object_list, 'categories': categories})

@login_required(login_url='accounts:login')
def cart(request):
	data = cartData(request) 

	cartItems = data['cartItems']
	order = data['order'] 
	items = data['items'] 
	print(items)
	context = {'items':items, 'order':order, 'cartItems':cartItems}
	return render(request, 'ecommerce/cart.html', context)

@login_required(login_url='accounts:login')
def checkout(request):
	data = cartData(request)
	
	cartItems = data['cartItems']
	order = data['order']
	items = data['items']

	context = {'items':items, 'order':order, 'cartItems':cartItems}
	return render(request, 'ecommerce/checkout.html', context)

@login_required(login_url='accounts:login')
def updateItem(request):
	data = json.loads(request.body)
	productId = data['productId']
	action = data['action']
	print('Action:', action)
	print('Product:', productId)
    
	customer = request.user.customer
	product = Product.objects.get(id=productId)
	order, created = Order.objects.get_or_create(customer=customer, complete=False)

	orderItem, created = OrderItem.objects.get_or_create(order=order, product=product)

	if action == 'add':
		orderItem.quantity = (orderItem.quantity + 1)
	elif action == 'remove':
		orderItem.quantity = (orderItem.quantity - 1)

	orderItem.save()

	if orderItem.quantity <= 0:
		orderItem.delete()

	return JsonResponse('Item was added', safe=False)



def verify_payment(request):
    if request.method == "POST":
        data = json.loads(request.body)
        reference = data.get("reference")
        user_data = data.get("user")
        total = float(data.get("total"))

        # Verify transaction with Paystack
        url = f"https://api.paystack.co/transaction/verify/{reference}"
        headers = {
            "Authorization": f"Bearer {settings.PAYSTACK_SECRET_KEY}",
        }
        response = requests.get(url, headers=headers)
        result = response.json()

        if result.get("status") and result["data"]["status"] == "success":
            # Get the customer instance
            customer = request.user.customer
            transaction_id = result["data"]["reference"]

            # Retrieve or create the order
            order, created = Order.objects.get_or_create(customer=customer, complete=False)
            order.transaction_id = transaction_id
            order.complete = True
            order.save()

            # Save the shipping address
            ShippingAddress.objects.create(
                customer=customer,
                order=order,
                address=user_data["address"],
                city=user_data["city"],
                state=user_data["state"],
            )

            return JsonResponse({"status": "success"})

        else:
            return JsonResponse(
                {"status": "failed", "message": result.get("message", "Payment verification failed.")}
            )


@login_required(login_url='accounts:login')
def processOrder(request):
    if request.method == "POST":
        transaction_id = str(datetime.datetime.now().timestamp())
        data = json.loads(request.body)

        # Get the customer instance
        customer = request.user.customer

        # Retrieve or create the order, ensuring only one incomplete order exists
        order, created = Order.objects.get_or_create(customer=customer, complete=False)

        # Check for a duplicate by verifying if the transaction ID has been set
        if order.transaction_id:
            return JsonResponse({'error': 'Order has already been processed'}, status=400)

        total = float(data['form']['total'])
        order.transaction_id = transaction_id

        # Confirm total matches cart total before marking complete
        if total == order.get_cart_total:
            order.complete = True
        order.save()

        # Save the shipping address
        ShippingAddress.objects.create(
            customer=customer,
            order=order,
            address=data['shipping']['address'],
            city=data['shipping']['city'],
            state=data['shipping']['state'],
        )

        return JsonResponse('Payment submitted..', safe=False)

@login_required(login_url='accounts:login')
def category_detail(request, slug):
	category = get_object_or_404(Category, slug=slug)
	products = category.products.all()
	categories = Category.objects.all()
	data = cartData(request)
	cartItems = data['cartItems']
	order = data['order']
	items = data['items']
	return render(request, 'ecommerce/categories.html', {'category': category, 'products': products,'categories':categories, 'cartItems':cartItems})

@login_required(login_url='accounts:login') 
def order_history(request):
	data = cartData(request)
	cartItems = data['cartItems']
	order = data['order']
	items = data['items']
	products = Product.objects.all()
	categories = Category.objects.all()
	customer = request.user.customer 
	orders = Order.objects.filter(customer=customer)
	return render(request, "ecommerce/orders.html", {'products':products, 'cartItems':cartItems,'categories': categories, "orders":orders})

@login_required(login_url='accounts:login')
def notifications(request):
	data = cartData(request)
	cartItems = data['cartItems']
	order = data['order']
	items = data['items']
	products = Product.objects.all()
	categories = Category.objects.all()
	model = Notification.objects.filter(customer=request.user.customer).order_by('-date_added')
	return render(request, "ecommerce/notifications.html", {'products':products, 'cartItems':cartItems,'categories': categories, 'notifications':model})

def privacy(request):
	return render(request, "privacy.html")
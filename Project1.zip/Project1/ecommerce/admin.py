from django.contrib import admin
from .models import *

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    readonly_fields = ('product', 'quantity', 'get_total')
    extra = 0

class OrderAdmin(admin.ModelAdmin):
    list_display = ('customer', 'transaction_id', 'date_ordered', 'complete')
    inlines = [OrderItemInline]

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('customer', 'title', 'date_added')

admin.site.register(Customer)
admin.site.register(Category)
admin.site.register(Product)
admin.site.register(Order, OrderAdmin)
admin.site.register(ShippingAddress)
admin.site.register(Notification)


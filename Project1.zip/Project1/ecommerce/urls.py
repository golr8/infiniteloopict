from django.urls import path

from . import views

urlpatterns = [
	path('', views.home, name="home"),
	path('myaccount/', views.myaccount, name="myaccount"),
	path('ecommerce/home/', views.store, name="store"),
	path('ecommerce/cart/', views.cart, name="cart"),
	path('ecommerce/checkout/', views.checkout, name="checkout"),
	path("ecommerce/verify_payment/", views.verify_payment, name="verify_payment"),
	path('ecommerce/update_item/', views.updateItem, name="update_item"),
	path('ecommerce/process_order/', views.processOrder, name="process_order"),
	path('ecommerce/search/', views.search, name="search"),
 	path('ecommerce/category/<slug:slug>/', views.category_detail, name='category'),
	path('ecommerce/notifications/', views.notifications, name='notifications'),
	path('ecommerce/order_history/', views.order_history, name='order_history'),
	path('privacy/terms/', views.privacy, name="privacy"),
]
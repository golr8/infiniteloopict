from django.shortcuts import render

# Create your views here.
def logistics(request):
    return render(request, 'logistics/logistics.html')
from django.contrib import admin

from .models import *

class DeliveryAdmin(admin.ModelAdmin):
    list_display = ('sender','reciever', 'price', 'date_ordered')
    
admin.site.register(Delivery)

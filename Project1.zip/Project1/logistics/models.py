from django.db import models
from django.contrib.auth.models import User
from django.contrib.auth import get_user_model
# Create your models here.
class Delivery(models.Model):
    customer = models.OneToOneField(get_user_model(), null=True, blank=True, on_delete=models.CASCADE)
    date_ordered = models.DateTimeField(auto_now_add=True)
    quantity = models.IntegerField(default=0, null=True, blank=True)
    value = models.FloatField()
    pickup_address = models.TextField(max_length=350)
    delivery_address = models.TextField(max_length=350)
    sender = models.CharField(max_length=150)
    sender_number = models.IntegerField(default=0, null=True, blank=True)
    sender_location = models.CharField(max_length=350, blank=True, null=True)
    sender_state = models.CharField(max_length=100)
    reciever = models.CharField(max_length=150)
    reciever_number = models.IntegerField(default=0, null=True, blank=True)
    reciever_location = models.CharField(max_length=350, blank=True, null=True)
    reciever_state = models.CharField(max_length=100)
    item_description = models.TextField()
    item_type = models.CharField(max_length=200)
    weight = models.FloatField()
    image = models.ImageField(upload_to="static\images")
    price = models.FloatField()
    

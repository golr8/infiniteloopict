import os
import sys
import importlib.util

# Add the project directory to the Python path
sys.path.insert(0, '/home/rejqgecmac/chenemona.com/home/Project1')

# Load the WSGI application
spec = importlib.util.spec_from_file_location('wsgi', '/home/rejqgecmac/chenemona.com/home/Project1/Main/wsgi.py')
wsgi_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(wsgi_module)

application = wsgi_module.application
